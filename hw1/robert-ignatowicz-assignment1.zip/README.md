The only external library used was dnspython.

When running mydig.py please use the following arguments:

./mydig.py DOMAIN_NAME

where DOMAIN_NAME is the domain name to be resolved.

If needed, you can simply run it with no arguments as in:

./mydig.py

to print the USAGE screen.