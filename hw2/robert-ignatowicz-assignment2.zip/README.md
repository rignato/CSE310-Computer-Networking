USAGE:  analysis_pcap_tcp.py <PCAP FILE> [SRC_IP] [DEST_IP]

Source and destination IP are optional.

This USAGE can be printed out by running the program with no arguments.